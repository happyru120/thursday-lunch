import ThursdayLunch from '@/components/ThursdayLunch'

export default function Home() {
  return <ThursdayLunch />
}
